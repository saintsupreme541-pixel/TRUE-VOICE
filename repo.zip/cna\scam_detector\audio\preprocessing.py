from __future__ import annotations

import io
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import soundfile as sf


SAMPLE_RATE = 16000


class AudioProcessingError(Exception):
    pass


def _decode_with_soundfile(audio_bytes: bytes):
    try:
        data, sr = sf.read(
            io.BytesIO(audio_bytes),
            dtype="float32",
            always_2d=False,
        )

        data = np.asarray(data, dtype=np.float32)

        if data.ndim > 1:
            data = np.mean(data, axis=1)

        if sr != SAMPLE_RATE:
            raise AudioProcessingError(
                f"Audio sample rate is {sr} Hz. "
                f"Expected {SAMPLE_RATE} Hz."
            )

        return data

    except Exception:
        return None


def _decode_with_ffmpeg(audio_bytes: bytes):

    input_path = None
    output_path = None

    try:

        with tempfile.NamedTemporaryFile(
            suffix=".input",
            delete=False,
        ) as f:

            f.write(audio_bytes)
            input_path = f.name


        with tempfile.NamedTemporaryFile(
            suffix=".wav",
            delete=False,
        ) as f:

            output_path = f.name


        command = [
            "ffmpeg",
            "-y",
            "-i",
            input_path,
            "-ar",
            str(SAMPLE_RATE),
            "-ac",
            "1",
            "-c:a",
            "pcm_s16le",
            output_path,
        ]


        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30,
        )


        if result.returncode != 0:

            error = result.stderr.decode(
                errors="ignore"
            )

            raise AudioProcessingError(
                "FFmpeg could not decode the audio: "
                + error[-1000:]
            )


        data, sr = sf.read(
            output_path,
            dtype="float32",
            always_2d=False,
        )


        data = np.asarray(
            data,
            dtype=np.float32
        )


        if data.ndim > 1:
            data = np.mean(
                data,
                axis=1
            )


        return data


    except FileNotFoundError:

        raise AudioProcessingError(
            "FFmpeg is not installed or is not "
            "available in PATH."
        )


    finally:

        for path in [
            input_path,
            output_path,
        ]:

            if path:

                try:
                    Path(path).unlink(
                        missing_ok=True
                    )

                except Exception:
                    pass


def decode_audio(
    audio_bytes: bytes
):

    if not audio_bytes:

        raise AudioProcessingError(
            "Empty audio file."
        )


    # First try WAV/standard formats directly.

    data = _decode_with_soundfile(
        audio_bytes
    )


    if data is None:

        # Browser WebM/Opus/etc.

        data = _decode_with_ffmpeg(
            audio_bytes
        )


    data = np.asarray(
        data,
        dtype=np.float32
    )


    if data.size == 0:

        raise AudioProcessingError(
            "Decoded audio contains no samples."
        )


    data = np.nan_to_num(
        data,
        nan=0.0,
        posinf=0.0,
        neginf=0.0,
    )


    duration = (
        len(data)
        / SAMPLE_RATE
    )


    rms = float(
        np.sqrt(
            np.mean(
                np.square(data)
            )
            + 1e-12
        )
    )


    metadata = {

        "sample_rate":
            SAMPLE_RATE,

        "channels":
            1,

        "samples":
            int(len(data)),

        "duration_seconds":
            round(
                duration,
                3
            ),

        "rms":
            round(
                rms,
                6
            ),
    }


    return data, metadata