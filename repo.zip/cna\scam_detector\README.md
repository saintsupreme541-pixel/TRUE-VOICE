# 🎙️ Scam Detector — Voice Call AI Detector

AI-powered voice-cloning / voice-spoof detection. Record from your microphone or upload an audio file and get a **HUMAN** vs **AI / SPOOF** verdict with a risk score.

Detection pipeline: **AASIST (ONNX) + 22 engineered features → StandardScaler → RandomForest** trained on 1,558 samples (508 human / 556 AI clean + real microphone data + synthetic mic augmentation).

> Latest recorded training metrics ([trained_model/training_report.json](trained_model/training_report.json)): validation **91.2%**, clean test **94.4%**, real-microphone holdout **96.7%** accuracy. These describe the training datasets, not a guarantee of real-world performance. The displayed percentages are the classifier's vote shares, not calibrated probabilities.

---

## Features

- **Live Detection** (`/`) — browser VAD with automatic stop after speech + 1.3 s silence; auto **NO VOICE DETECTED** if no speech within 9 s; audio-reactive visualizer; manual *Stop & Analyze* retained
- **Upload Audio** (`/upload`) — drag & drop or picker; WAV, MP3, FLAC, OGG, M4A, AAC, WebM
- **Voice gate** — backend double-check (duration + RMS + voiced ratio) before running the model
- **Any sample rate** — resampled to 16 kHz mono automatically (`resampled: true` in metadata)
- **Robust decoding** — system FFmpeg if available, else the bundled `imageio-ffmpeg` binary (no manual FFmpeg install needed)
- **Warm startup** — librosa/numba kernels compiled at boot; first request is fast (~0.8 s for 4 s audio)
- Truthful errors: empty (400), corrupt/undecodable (400), oversized >25 MB (413)
- Verdict signals: 🟢 GREEN <40 / 🟡 YELLOW 40–69 / 🔴 RED ≥70 / ⚪ GREY = no voice
- Audio is processed in memory only — never stored

## Run

```bash
pip install -r requirements.txt   # adds imageio-ffmpeg (bundled decoder)
python app.py                     # warms up (~4 s), then serves
```

Open **http://127.0.0.1:8000** (live) and **http://127.0.0.1:8000/upload** (file analysis).

## API

| Endpoint | Method | Description |
|---|---|---|
| `/` | GET | Live detection UI |
| `/upload` | GET | Upload UI |
| `/health` | GET | Service/model info |
| `/check_voice` | POST | Multipart `audio` field → verdict JSON |
| `/favicon.ico` | GET | Inline SVG icon |

```bash
curl -F "audio=@sample.wav" http://127.0.0.1:8000/check_voice
```

Response (success): `label`, `signal`, `risk_score`, `human_confidence`, `ai_probability`, `aasist` logits, `voice_metrics` (rms / voiced_ratio), `metadata` (duration / resampled), `latency_ms`. No-voice responses return `voice_detected: false` with `label: "NO VOICE DETECTED"`.

## Training

1. Put human recordings in `dataset/human/`, AI ones in `dataset/ai/`; optional real-mic data in `dataset/microphone/{human,ai}/`.
2. `python train.py` → writes `trained_model/voice_call_model.joblib` + `training_report.json`.
3. `python test_model.py` — quick sanity check on sample files (requires the dataset).

The inference feature extraction in `app.py` matches `train.py`'s definitions and order (pyin C2–C7, librosa-default frame/hop, jitter = mean|Δf0|/mean f0).

## Project structure

```
scam_detector/
├── app.py                  # FastAPI backend + decoding + 22-feature pipeline
├── train.py                # Trains the fusion model
├── test_model.py           # Manual smoke test (needs dataset/)
├── aasist.onnx             # Pre-trained AASIST anti-spoofing model
├── requirements.txt
├── audio/preprocessing.py  # Legacy decoder (app.py now has its own robust decoder)
├── templates/              # index.html (live), upload.html
├── static/                 # script.js (VAD + visualizer), upload.js, styles.css
└── trained_model/          # voice_call_model.joblib + training_report.json
```

## Notes

- Uploaded audio >25 MB is rejected; longer recordings are analyzed in full (60 s ≈ 4–5 s processing).
- Pure noise can still pass the voiced-ratio gate and receive a verdict; treat low-risk scores on obvious non-speech with skepticism.
- `predict_proba` outputs are model vote shares, not calibrated probabilities.

# TRUE-VOICE
