"""Standalone performance / concurrency / memory measurement script.

Run:  python tests/perf_check.py
Prints real measured numbers; nothing is invented.
"""
from __future__ import annotations

import io
import statistics
import subprocess
import sys
import threading
import time
import wave
from pathlib import Path

import httpx
import psutil

ROOT = Path(__file__).resolve().parent.parent
PORT = 8766
BASE = f"http://127.0.0.1:{PORT}"


def wav_bytes(seconds: float, sr: int = 16000) -> bytes:
    n = int(sr * seconds)
    t = __import__("numpy").arange(n) / sr
    f0 = 140
    y = 0.4 * __import__("numpy").sign(__import__("numpy").sin(2 * __import__("numpy").pi * f0 * t)) * __import__("numpy").exp(-3 * ((t * 4) % 1))
    y += 0.2 * __import__("numpy").sin(2 * __import__("numpy").pi * f0 * 2 * t)
    y = __import__("numpy").clip(y, -1, 1)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((y * 32767).astype("<i2").tobytes())
    return buf.getvalue()


def wait_healthy(timeout=120) -> subprocess.Popen:
    import os
    import socket
    proc = subprocess.Popen(
        [sys.executable, "-c",
         "import sys; sys.path.insert(0, '.');"
         "t0=time.perf_counter(); import app; app._warmup();"
         f"print('READY_IN {{:.1f}}s'.format(time.perf_counter()-t0), flush=True);"
         f"import uvicorn; uvicorn.run(app.app, host='127.0.0.1', port={PORT})"],
        cwd=str(ROOT), env=dict(os.environ),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    t0 = time.perf_counter()
    while time.perf_counter() - t0 < timeout:
        try:
            r = httpx.get(f"{BASE}/health", timeout=3)
            if r.status_code == 200:
                return proc
        except Exception:
            pass
        time.sleep(0.3)
    proc.kill()
    raise RuntimeError("server did not start")


def post(client, payload):
    t0 = time.perf_counter()
    r = client.post("/check_voice", files={"audio": ("p.wav", payload, "audio/wav")})
    return r, (time.perf_counter() - t0) * 1000


def main() -> None:
    # ---- cold start ----
    t0 = time.perf_counter()
    proc = wait_healthy()
    cold_total = (time.perf_counter() - t0) * 1000
    line = proc.stdout.readline().decode().strip() if proc.stdout else ""
    print(f"COLD_START: health OK after {cold_total:.0f} ms ({line})")

    proc_ps = psutil.Process(proc.pid)
    rss0 = proc_ps.memory_info().rss / 1024 / 1024
    print(f"RSS after startup: {rss0:.0f} MB")

    try:
        with httpx.Client(base_url=BASE, timeout=300) as client:
            # ---- warm inference min/avg/max ----
            payload4 = wav_bytes(4.0)
            post(client, payload4)  # ensure fully warm
            times = []
            for _ in range(10):
                r, ms = post(client, payload4)
                assert r.status_code == 200
                times.append(ms)
            print(f"WARM_4S x10: min={min(times):.0f} avg={statistics.mean(times):.0f} max={max(times):.0f} ms")

            # ---- duration scaling ----
            for secs in (1, 5, 30, 60):
                p = wav_bytes(secs)
                r, ms = post(client, p)
                d = r.json()
                print(f"DURATION {secs:>3}s: {ms:.0f} ms (server {d.get('latency_ms')} ms)")

            # ---- memory growth over repeated inference ----
            for i in range(15):
                post(client, payload4)
            rss1 = proc_ps.memory_info().rss / 1024 / 1024
            print(f"RSS after 25 more inferences: {rss1:.0f} MB (delta {rss1 - rss0:+.0f} MB)")

            # ---- concurrency 2 and 5 ----
            for workers in (2, 5):
                results, errors = [], []
                lock = threading.Lock()

                def run():
                    try:
                        r, ms = post(client, payload4)
                        with lock:
                            results.append((r.status_code, ms, r.json().get("detection_score")))
                    except Exception as e:
                        with lock:
                            errors.append(str(e))

                threads = [threading.Thread(target=run) for _ in range(workers)]
                t1 = time.perf_counter()
                for th in threads:
                    th.start()
                for th in threads:
                    th.join()
                wall = (time.perf_counter() - t1) * 1000
                codes = [c for c, _, _ in results]
                scores = {s for _, _, s in results}
                print(f"CONCURRENT x{workers}: wall={wall:.0f} ms codes={codes} "
                      f"scores_consistent={len(scores) == 1} errors={errors[:2]}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()


if __name__ == "__main__":
    main()
