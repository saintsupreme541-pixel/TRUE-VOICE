from __future__ import annotations

import numpy as np
import librosa

try:
    import webrtcvad
except Exception:  # pragma: no cover - optional dependency
    webrtcvad = None

SR = 16000

VAD_CONFIG = {
    "aggressiveness": 2,
    "frame_ms": 30,
    "min_speech_ms": 240,
    "min_speech_ms_uncertain": 90,
    "abs_quiet_rms": 0.0015,
    "min_envelope_cv": 0.25,
    "noise_flatness": 0.45,
    "stationary_run_ms": 1200,
    "stationary_cv": 0.15,
    "min_speech_ratio": 0.08,
    "min_voiced_ms": 900,
    "short_audio_seconds": 0.5,
}

STATE_ALIASES = {
    "SPEECH": "VALID_SPEECH",
    "NO_SPEECH": "NO_VOICE",
    "UNCERTAIN": "UNCERTAIN_AUDIO",
    "INSUFFICIENT_SPEECH": "INSUFFICIENT_SPEECH",
}


def _result(state: str, reason: str, voice_detected: bool, *, voiced_ms: int, speech_ratio: float, envelope_cv: float, longest_run_ms: int, flatness: float | None, rms: float) -> dict:
    result = {
        "state": state,
        "state_name": STATE_ALIASES.get(state, state),
        "voice_detected": bool(voice_detected),
        "reason": reason,
        "voiced_ms": voiced_ms,
        "speech_ratio": round(float(speech_ratio), 3),
        "envelope_cv": round(float(envelope_cv), 3),
        "longest_run_ms": longest_run_ms,
        "flatness": round(float(flatness), 4) if flatness is not None else None,
        "rms": round(float(rms), 6),
    }
    return result


def validate_speech(y: np.ndarray) -> dict:
    """Return a compact speech-validation verdict with evidence.

    The gate is intentionally conservative: any ambiguous or stationary non-speech
    sample is rejected before model inference, while true speech keeps a clear path.
    """
    y = np.asarray(y, dtype=np.float32)
    if y is None or y.size == 0:
        return _result(
            "NO_SPEECH",
            "empty audio",
            False,
            voiced_ms=0,
            speech_ratio=0.0,
            envelope_cv=0.0,
            longest_run_ms=0,
            flatness=1.0,
            rms=0.0,
        )

    if y.size < int(0.25 * SR):
        return _result(
            "INSUFFICIENT_SPEECH",
            "clip shorter than 0.25 s",
            False,
            voiced_ms=0,
            speech_ratio=0.0,
            envelope_cv=0.0,
            longest_run_ms=0,
            flatness=1.0,
            rms=float(np.sqrt(np.mean(np.square(y)) + 1e-12)),
        )

    rms = float(np.sqrt(np.mean(np.square(y)) + 1e-12))
    peak = float(np.max(np.abs(y)))
    if peak < 1e-6:
        return _result(
            "NO_SPEECH",
            "digital silence",
            False,
            voiced_ms=0,
            speech_ratio=0.0,
            envelope_cv=0.0,
            longest_run_ms=0,
            flatness=1.0,
            rms=rms,
        )

    if webrtcvad is None:
        return _result(
            "NO_SPEECH",
            "webrtcvad unavailable; rejecting for safety",
            False,
            voiced_ms=0,
            speech_ratio=0.0,
            envelope_cv=0.0,
            longest_run_ms=0,
            flatness=1.0,
            rms=rms,
        )

    work = y / peak if peak > 1.0 else y
    pcm = (work * 32767).astype(np.int16)

    frame_len = int(SR * VAD_CONFIG["frame_ms"] / 1000)
    vad = webrtcvad.Vad(VAD_CONFIG["aggressiveness"])
    flags: list[int] = []
    frame_rms: list[float] = []
    for i in range(0, len(pcm) - frame_len + 1, frame_len):
        fr = pcm[i : i + frame_len]
        try:
            flags.append(1 if vad.is_speech(fr.tobytes(), SR) else 0)
        except Exception:
            flags.append(0)
        frame_rms.append(float(np.sqrt(np.mean((fr.astype(np.float32) / 32767.0) ** 2) + 1e-12)))

    if not flags:
        return _result(
            "INSUFFICIENT_SPEECH",
            "no complete frames",
            False,
            voiced_ms=0,
            speech_ratio=0.0,
            envelope_cv=0.0,
            longest_run_ms=0,
            flatness=1.0,
            rms=rms,
        )

    fa = np.asarray(flags, dtype=int)
    voiced_ms = int(fa.sum()) * VAD_CONFIG["frame_ms"]
    speech_ratio = voiced_ms / (len(fa) * VAD_CONFIG["frame_ms"])
    rms_arr = np.asarray(frame_rms, dtype=np.float32)
    envelope_cv = float(np.std(rms_arr) / (np.mean(rms_arr) + 1e-9))
    longest_run = 0
    run = 0
    for flag in fa:
        run = run + 1 if flag else 0
        longest_run = max(longest_run, run)
    longest_run_ms = longest_run * VAD_CONFIG["frame_ms"]

    flatness = None
    try:
        flatness = float(np.mean(librosa.feature.spectral_flatness(y=y)))
    except Exception:
        flatness = None

    p95_rms = float(np.percentile(rms_arr, 95))
    if p95_rms < VAD_CONFIG["abs_quiet_rms"]:
        return _result(
            "NO_SPEECH",
            "audio is effectively silence",
            False,
            voiced_ms=voiced_ms,
            speech_ratio=speech_ratio,
            envelope_cv=envelope_cv,
            longest_run_ms=longest_run_ms,
            flatness=flatness,
            rms=rms,
        )

    if flatness is not None and flatness >= VAD_CONFIG["noise_flatness"] and envelope_cv < VAD_CONFIG["min_envelope_cv"]:
        return _result(
            "NO_SPEECH",
            "broadband noise without speech-like modulation",
            False,
            voiced_ms=voiced_ms,
            speech_ratio=speech_ratio,
            envelope_cv=envelope_cv,
            longest_run_ms=longest_run_ms,
            flatness=flatness,
            rms=rms,
        )

    if longest_run_ms >= VAD_CONFIG["stationary_run_ms"] and envelope_cv < VAD_CONFIG["stationary_cv"]:
        return _result(
            "NO_SPEECH",
            "stationary sound (tone/hum/music bed) with no speech structure",
            False,
            voiced_ms=voiced_ms,
            speech_ratio=speech_ratio,
            envelope_cv=envelope_cv,
            longest_run_ms=longest_run_ms,
            flatness=flatness,
            rms=rms,
        )

    if longest_run_ms >= 3000 and speech_ratio >= 0.9 and envelope_cv < 0.35:
        return _result(
            "NO_SPEECH",
            "stationary non-speech signal dominated by one long voiced run",
            False,
            voiced_ms=voiced_ms,
            speech_ratio=speech_ratio,
            envelope_cv=envelope_cv,
            longest_run_ms=longest_run_ms,
            flatness=flatness,
            rms=rms,
        )

    if voiced_ms < VAD_CONFIG["min_voiced_ms"]:
        return _result(
            "INSUFFICIENT_SPEECH",
            "too little voiced material to analyze",
            False,
            voiced_ms=voiced_ms,
            speech_ratio=speech_ratio,
            envelope_cv=envelope_cv,
            longest_run_ms=longest_run_ms,
            flatness=flatness,
            rms=rms,
        )

    if speech_ratio < VAD_CONFIG["min_speech_ratio"]:
        return _result(
            "INSUFFICIENT_SPEECH",
            "speech coverage below minimum",
            False,
            voiced_ms=voiced_ms,
            speech_ratio=speech_ratio,
            envelope_cv=envelope_cv,
            longest_run_ms=longest_run_ms,
            flatness=flatness,
            rms=rms,
        )

    if envelope_cv < VAD_CONFIG["min_envelope_cv"] and speech_ratio >= 0.5:
        return _result(
            "NO_SPEECH",
            "non-modulated stationary signal mistaken for speech by VAD",
            False,
            voiced_ms=voiced_ms,
            speech_ratio=speech_ratio,
            envelope_cv=envelope_cv,
            longest_run_ms=longest_run_ms,
            flatness=flatness,
            rms=rms,
        )

    if envelope_cv >= VAD_CONFIG["min_envelope_cv"] and voiced_ms >= VAD_CONFIG["min_speech_ms"]:
        return _result(
            "SPEECH",
            "modulated, speech-like audio with enough voiced material",
            True,
            voiced_ms=voiced_ms,
            speech_ratio=speech_ratio,
            envelope_cv=envelope_cv,
            longest_run_ms=longest_run_ms,
            flatness=flatness,
            rms=rms,
        )

    if voiced_ms >= VAD_CONFIG["min_speech_ms_uncertain"]:
        return _result(
            "UNCERTAIN",
            "some speech-like material but weak or conflicting structure; result is flagged",
            True,
            voiced_ms=voiced_ms,
            speech_ratio=speech_ratio,
            envelope_cv=envelope_cv,
            longest_run_ms=longest_run_ms,
            flatness=flatness,
            rms=rms,
        )

    return _result(
        "INSUFFICIENT_SPEECH",
        "too little voiced material to analyze",
        False,
        voiced_ms=voiced_ms,
        speech_ratio=speech_ratio,
        envelope_cv=envelope_cv,
        longest_run_ms=longest_run_ms,
        flatness=flatness,
        rms=rms,
    )
