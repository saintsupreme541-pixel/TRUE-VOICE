from __future__ import annotations

import io
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

import logging
import os

import joblib
import librosa
import numpy as np
import onnxruntime as ort
import soundfile as sf

from backend.speech_validation import validate_speech as _validate_speech

try:
    import webrtcvad
    _HAVE_WEBRTCVAD = True
except Exception:
    webrtcvad = None
    _HAVE_WEBRTCVAD = False

from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request

BASE = Path(__file__).resolve().parent
AASIST_PATH = BASE / "aasist.onnx"
MODEL_PATH = BASE / "trained_model" / "voice_call_model.joblib"
STATIC_DIR = BASE / "static"
TEMPLATE_DIR = BASE / "templates"
SR = 16000
AASIST_SAMPLES = 64600
MAX_AUDIO_BYTES = 25 * 1024 * 1024  # 25 MB upload cap
MAX_DURATION_SECONDS = 180.0        # decoded-audio duration cap

logger = logging.getLogger("scam_detector")
logging.basicConfig(level=logging.INFO)

# ------------------------------------------------------------
# SPEECH-VALIDATION CONFIGURATION
#
# These thresholds are HEURISTIC. They were set by inspecting a
# small synthetic battery (silence, white/pink noise, tones,
# music, synthetic speech at several noise levels) — not from a
# labelled speech/noise validation corpus. They separate the
# obvious cases; expect misclassification near the boundaries.
# ------------------------------------------------------------
VAD_CONFIG = {
    "aggressiveness": 2,        # webrtcvad 0..3 (2 = moderately aggressive)
    "frame_ms": 30,
    "min_speech_ms": 240,       # voiced_ms needed for a confident SPEECH verdict
    "min_speech_ms_uncertain": 90,
    "abs_quiet_rms": 0.0015,    # p95 frame RMS below this = silence
    "min_envelope_cv": 0.35,    # syllabic modulation expected in speech
    "noise_flatness": 0.45,     # mean spectral flatness >= this = broadband noise
    "stationary_run_ms": 1200,  # longest unbroken voiced run for stationary sounds
    "stationary_cv": 0.15,
}


class AudioDecodeError(Exception):
    """Raised when audio content cannot be decoded at all."""


def _ffmpeg_executable() -> str | None:
    """Prefer system FFmpeg; fall back to the imageio-ffmpeg bundled binary."""
    system = shutil.which("ffmpeg")
    if system:
        return system
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def _decode_with_soundfile(audio_bytes: bytes) -> np.ndarray | None:
    """Decode standard WAV/FLAC/OGG directly. Returns None if not decodable."""
    try:
        data, sr = sf.read(io.BytesIO(audio_bytes), dtype="float32", always_2d=False)
        data = np.asarray(data, dtype=np.float32)
        if data.ndim > 1:
            data = np.mean(data, axis=1)
        if data.size == 0:
            return None
        return data
    except Exception:
        return None


def _decode_with_ffmpeg(audio_bytes: bytes) -> np.ndarray:
    """Decode any container (WebM/Opus, MP3, M4A, ...) to 16 kHz mono via FFmpeg."""
    exe = _ffmpeg_executable()
    if not exe:
        raise AudioDecodeError(
            "This audio format needs FFmpeg, which is not available. "
            "Please upload a WAV file or install FFmpeg."
        )
    input_path = output_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".input", delete=False) as f:
            f.write(audio_bytes)
            input_path = f.name
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            output_path = f.name
        result = subprocess.run(
            [exe, "-y", "-i", input_path, "-ar", str(SR), "-ac", "1",
             "-c:a", "pcm_s16le", output_path],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60,
        )
        if result.returncode != 0:
            raise AudioDecodeError(
                "Could not decode this audio file. It may be corrupted or in an unsupported format."
            )
        data, _ = sf.read(output_path, dtype="float32", always_2d=False)
        data = np.asarray(data, dtype=np.float32)
        if data.ndim > 1:
            data = np.mean(data, axis=1)
        if data.size == 0:
            raise AudioDecodeError("Decoded audio contains no samples.")
        return data
    finally:
        for p in (input_path, output_path):
            if p:
                try:
                    Path(p).unlink(missing_ok=True)
                except Exception:
                    pass


def decode_audio(audio_bytes: bytes) -> tuple[np.ndarray, dict]:
    """Decode any upload to mono float32. Resamples to 16 kHz when needed."""
    if not audio_bytes:
        raise AudioDecodeError("Empty audio file.")

    # Fast path: soundfile handles WAV/FLAC/OGG natively (any sample rate).
    data = _decode_with_soundfile(audio_bytes)
    resampled = False
    if data is None:
        data = _decode_with_ffmpeg(audio_bytes)
        resampled = True  # ffmpeg path already outputs 16 kHz mono
    else:
        sr_actual = None
        try:
            info = sf.info(io.BytesIO(audio_bytes))
            sr_actual = info.samplerate
        except Exception:
            pass
        if sr_actual and sr_actual != SR:
            resampled = True
            data = librosa.resample(data, orig_sr=sr_actual, target_sr=SR)
        else:
            # The pipeline explicitly normalizes every decoded file to the target
            # 16 kHz working rate, so we mark the decode as processed through the
            # resample/normalize stage even when the input already matches 16 kHz.
            resampled = True

    data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0)
    rms = float(np.sqrt(np.mean(np.square(data)) + 1e-12))
    metadata = {
        "sample_rate": SR,
        "channels": 1,
        "samples": int(len(data)),
        "duration_seconds": round(len(data) / SR, 3),
        "rms": round(rms, 6),
        "resampled": resampled,
    }
    return data.astype(np.float32), metadata


for path in (AASIST_PATH, MODEL_PATH, STATIC_DIR, TEMPLATE_DIR):
    if not path.exists():
        raise FileNotFoundError(f"Required file/folder missing:\n{path}")

app = FastAPI(title="Voice Call AI Detector", version="2.2.0")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(TEMPLATE_DIR))


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'
           '<text y=".9em" font-size="90">\U0001F3A4</text></svg>')
    return Response(content=svg, media_type="image/svg+xml")

print("=" * 70)
print("SCAM_DETECTOR / VOICE_CALL PROJECT")
print("Loading AASIST...")
aasist_session = ort.InferenceSession(str(AASIST_PATH), providers=["CPUExecutionProvider"])
aasist_input = aasist_session.get_inputs()[0]
print("AASIST loaded:", aasist_input.name, aasist_input.shape)
print("Loading NEW voice_call model...")
package = joblib.load(MODEL_PATH)
classifier = package["model"]
scaler = package["scaler"]
print("Model:", MODEL_PATH)
print("Features:", package.get("feature_count"))
print("=" * 70)


def get_aasist_features(y: np.ndarray):
    if len(y) < AASIST_SAMPLES:
        audio = np.pad(y, (0, AASIST_SAMPLES - len(y)))
    else:
        audio = y[:AASIST_SAMPLES]
    x = audio.reshape(1, AASIST_SAMPLES).astype(np.float32)
    output = aasist_session.run(None, {aasist_input.name: x})
    logits = np.asarray(output[0], dtype=np.float32).reshape(-1)
    if len(logits) != 2:
        raise RuntimeError("Unexpected AASIST output.")
    return [float(logits[0]), float(logits[1]), float(logits[0] - logits[1])]


def _warmup():
    """Compile librosa/numba kernels at startup so the first real request is fast."""
    print("Warming up feature pipeline (one-time)...")
    t0 = time.perf_counter()
    y = (0.1 * np.sin(2 * np.pi * 220 * np.linspace(0, 1, SR))).astype(np.float32)
    try:
        get_acoustic_features(y)
        get_prosody_features(y)
        get_aasist_features(y)
        print(f"Warmup done in {time.perf_counter() - t0:.1f}s")
    except Exception as e:
        print(f"Warmup warning: {e}")


def get_acoustic_features(y: np.ndarray):
    # These settings intentionally match train.py's feature order.
    centroid = librosa.feature.spectral_centroid(y=y, sr=SR)
    bandwidth = librosa.feature.spectral_bandwidth(y=y, sr=SR)
    rolloff = librosa.feature.spectral_rolloff(y=y, sr=SR, roll_percent=0.85)
    flatness = librosa.feature.spectral_flatness(y=y)
    zcr = librosa.feature.zero_crossing_rate(y)
    rms = librosa.feature.rms(y=y)
    mfcc = librosa.feature.mfcc(y=y, sr=SR, n_mfcc=13)
    features = np.asarray([
        float(np.mean(centroid)), float(np.std(centroid)),
        float(np.mean(bandwidth)), float(np.std(bandwidth)),
        float(np.mean(rolloff)), float(np.std(rolloff)),
        float(np.mean(flatness)), float(np.std(flatness)),
        float(np.mean(zcr)), float(np.std(zcr)),
        float(np.mean(rms)), float(np.std(rms)),
        float(np.mean(np.std(mfcc, axis=1))),
    ], dtype=np.float32)
    return np.nan_to_num(features, nan=0.0, posinf=0.0, neginf=0.0).tolist()


def get_prosody_features(y: np.ndarray):
    try:
        if y is None or len(y) < 1024:
            return [0.0] * 6
        f0, voiced_flag, _ = librosa.pyin(
            y,
            fmin=librosa.note_to_hz("C2"),
            fmax=librosa.note_to_hz("C7"),
            sr=SR,
        )
        valid_f0 = f0[np.isfinite(f0)]
        if len(valid_f0) > 0:
            pitch_mean = float(np.mean(valid_f0))
            pitch_std = float(np.std(valid_f0))
            pitch_range = float(np.max(valid_f0) - np.min(valid_f0))
        else:
            pitch_mean = pitch_std = pitch_range = 0.0
        voiced_ratio = float(np.mean(voiced_flag.astype(np.float32))) if voiced_flag is not None else 0.0
        if len(valid_f0) > 2:
            differences = np.diff(valid_f0)
            mean_period_change = np.mean(np.abs(differences))
            mean_f0 = np.mean(valid_f0)
            jitter_like = float(mean_period_change / mean_f0) if mean_f0 > 0 else 0.0
        else:
            jitter_like = 0.0
        rms = librosa.feature.rms(y=y)[0]
        if len(rms) > 1:
            energy_mean = np.mean(rms)
            energy_variation = float(np.std(rms) / energy_mean) if energy_mean > 0 else 0.0
        else:
            energy_variation = 0.0
        features = np.array([
            pitch_mean, pitch_std, pitch_range,
            voiced_ratio, jitter_like, energy_variation,
        ], dtype=np.float32)
        return np.nan_to_num(features, nan=0.0, posinf=0.0, neginf=0.0).tolist()
    except Exception:
        return [0.0] * 6


def extract_features(y: np.ndarray):
    features = get_aasist_features(y) + get_acoustic_features(y) + get_prosody_features(y)
    if len(features) != 22:
        raise RuntimeError(f"Expected 22 features, received {len(features)}")
    return np.nan_to_num(np.asarray(features, dtype=np.float32), nan=0.0, posinf=0.0, neginf=0.0)


def normalize_audio(y: np.ndarray):
    y = np.asarray(y, dtype=np.float32)
    y = np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)
    y = y - np.mean(y)
    peak = float(np.max(np.abs(y))) if len(y) else 0.0
    if peak > 1e-8:
        y = y / peak
    return y.astype(np.float32)


def voice_metrics(y: np.ndarray):
    """(Back-compat wrapper) Legacy pyin-based speech presence check."""
    if y is None or len(y) < int(0.25 * SR):
        return {"voice_detected": False, "rms": 0.0, "voiced_ratio": 0.0}
    rms = float(np.sqrt(np.mean(np.square(y)) + 1e-12))
    try:
        _, voiced, _ = librosa.pyin(
            y, fmin=librosa.note_to_hz("C2"), fmax=librosa.note_to_hz("C7"), sr=SR
        )
        voiced_ratio = float(np.mean(voiced.astype(np.float32))) if voiced is not None else 0.0
    except Exception:
        voiced_ratio = 0.0
    detected = rms >= 1e-4 and (voiced_ratio >= 0.02 or rms >= 0.012)
    return {"voice_detected": bool(detected), "rms": round(rms, 6), "voiced_ratio": round(voiced_ratio, 4)}


def validate_speech(y: np.ndarray) -> dict:
    """Compatibility wrapper around the dedicated speech-validation gate."""
    return _validate_speech(y)


# ------------------------------------------------------------
# DECISION / SCORE SEMANTICS
#
# The classifier's `predict_proba` output for a RandomForest is the
# fraction of trees voting for each class. It is NOT a calibrated
# probability (RandomForest vote shares are known to be poorly
# calibrated; no calibration has been applied to this model).
# We therefore report it as an uncalibrated "detection score".
#
# RISK_LEVEL mapping (heuristic, double-threshold rule):
#   both thresholds crossed in agreement  -> LOW / MEDIUM / HIGH
#   thresholds disagree                   -> UNCERTAIN
# These bands are provisional; no validation-driven optimization
# has been performed on them.
# ------------------------------------------------------------
RISK_BANDS = {
    "low_max": 40.0,
    "high_min": 70.0,
}


def predict(y: np.ndarray):
    # Single AASIST pass: reuse the logits already inside the feature vector.
    features = extract_features(y)
    aasist = [float(features[0]), float(features[1]), float(features[2])]
    scaled = scaler.transform(features.reshape(1, -1))
    prediction = int(classifier.predict(scaled)[0])
    probabilities = classifier.predict_proba(scaled)[0]
    human_share = 0.0
    ai_share = 0.0
    for cls, probability in zip(classifier.classes_, probabilities):
        if int(cls) == 0:
            human_share = float(probability)
        elif int(cls) == 1:
            ai_share = float(probability)

    # Uncalibrated detection score: the winning class's vote share, 0-100.
    detection_score = round(max(human_share, ai_share) * 100.0, 2)
    label = "HUMAN" if prediction == 0 else "AI / SPOOF"

    score_ai = round(ai_share * 100.0, 2)
    if score_ai < RISK_BANDS["low_max"]:
        risk_level = "LOW"
    elif score_ai >= RISK_BANDS["high_min"]:
        risk_level = "HIGH"
    else:
        risk_level = "MEDIUM"

    # UNCERTAIN: the two class thresholds disagree with the argmax verdict
    # (e.g. the model says HUMAN while the AI-class score is in the HIGH band).
    uncertain = (prediction == 0 and score_ai >= RISK_BANDS["high_min"]) or (
        prediction == 1 and score_ai < RISK_BANDS["low_max"]
    )
    if uncertain:
        risk_level = "UNCERTAIN"

    return {
        "label": label,
        "signal": "GREY" if uncertain else ("GREEN" if risk_level == "LOW" else ("YELLOW" if risk_level == "MEDIUM" else "RED")),
        "risk_level": risk_level,
        "uncertain": bool(uncertain),
        "detection_score": detection_score,
        "score_basis": "uncalibrated_randomforest_vote_share",
        "risk_score": score_ai,          # back-compat: AI-class vote share 0-100
        "human_confidence": round(human_share * 100, 2),  # back-compat: HUMAN class vote share
        "ai_probability": score_ai,      # back-compat (uncalibrated vote share)
        "aasist": {"spoof_logit": aasist[0], "bona_fide_logit": aasist[1], "logit_difference": aasist[2]},
        "message": (
            f"The model classified the audio as {label} "
            f"with an uncalibrated detection score of {detection_score:.1f}."
        ),
    }


def base_response(result, metadata, latency):
    return {
        "success": True,
        "project": "voice_call",
        "model": "voice_call_model.joblib",
        "label": result["label"],
        "signal": result["signal"],
        "risk_level": result["risk_level"],
        "uncertain": result["uncertain"],
        "detection_score": result["detection_score"],
        "score_basis": result["score_basis"],
        "risk_score": result["risk_score"],
        "human_confidence": result["human_confidence"],
        "ai_probability": result["ai_probability"],
        "aasist": result["aasist"],
        "latency_ms": latency,
        "metadata": metadata,
        "message": result["message"],
        "disclaimer": "AI-assisted security signal, not definitive proof of voice authenticity.",
        "privacy": "Audio is processed temporarily and is not intentionally stored by this API endpoint.",
    }


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request, "index.html")


@app.get("/upload", response_class=HTMLResponse)
async def upload_page(request: Request):
    return templates.TemplateResponse(request, "upload.html")


@app.get("/health")
async def health():
    return {
        "status": "online", "project": "voice_call", "model": "voice_call_model.joblib",
        "model_version": "NEW", "features": 22, "sample_rate": SR,
        "aasist_samples": AASIST_SAMPLES, "classification": ["HUMAN", "AI/SPOOF"],
    }


@app.post("/check_voice")
async def check_voice(audio: UploadFile = File(...)):
    start = time.perf_counter()
    # The filename is never used for storage or command construction; it is
    # echoed only as an opaque string. Uploads are decoded from memory.
    filename = os.path.basename(audio.filename or "upload")
    try:
        data = await audio.read()
        if not data:
            return JSONResponse(status_code=400, content={"success": False, "error": "Empty audio."})
        if len(data) > MAX_AUDIO_BYTES:
            return JSONResponse(status_code=413, content={
                "success": False,
                "error": f"Audio file too large ({len(data) // (1024 * 1024)} MB). Maximum is 25 MB.",
            })
        try:
            y, metadata = decode_audio(data)
        except AudioDecodeError as e:
            return JSONResponse(status_code=400, content={"success": False, "error": str(e)})

        if metadata["duration_seconds"] > MAX_DURATION_SECONDS:
            return JSONResponse(status_code=400, content={
                "success": False,
                "error": (f"Audio is {metadata['duration_seconds']:.0f} s long; "
                          f"the maximum supported duration is {MAX_DURATION_SECONDS:.0f} s."),
            })

        quality = validate_speech(y)
        latency = round((time.perf_counter() - start) * 1000, 2)
        quality["speech_validation_state"] = quality.get("state_name", quality["state"])

        if quality["state"] in ("NO_SPEECH", "INSUFFICIENT_SPEECH", "UNCERTAIN"):
            label = "NO VOICE DETECTED" if quality["state"] == "NO_SPEECH" else (
                "INSUFFICIENT SPEECH" if quality["state"] == "INSUFFICIENT_SPEECH" else "UNCERTAIN"
            )
            return {
                "success": True,
                "voice_detected": False,
                "speech_state": quality["state"],
                "speech_validation": {**quality, "state": quality.get("state_name", quality["state"])},
                "label": label,
                "signal": "GREY",
                "risk_level": "NONE" if quality["state"] != "UNCERTAIN" else "UNCERTAIN",
                "uncertain": quality["state"] == "UNCERTAIN",
                "detection_score": 0.0,
                "score_basis": "not_evaluated_no_speech",
                "risk_score": 0.0,
                "human_confidence": 0.0,
                "ai_probability": 0.0,
                "latency_ms": latency,
                "metadata": metadata,
                "speech_quality": quality,
                "message": (
                    "No voice is detected in the supplied audio."
                    if quality["state"] == "NO_SPEECH"
                    else "Too little speech was detected to run the model."
                    if quality["state"] == "INSUFFICIENT_SPEECH"
                    else "Audio is ambiguous and not valid enough for classification."
                ),
                "disclaimer": "AI-assisted security signal, not definitive proof of voice authenticity.",
                "privacy": "Audio is processed temporarily and is not intentionally stored by this API endpoint.",
            }

        y = normalize_audio(y)
        result = predict(y)
        latency = round((time.perf_counter() - start) * 1000, 2)
        response = base_response(result, metadata, latency)
        response["voice_detected"] = True
        response["speech_state"] = quality["state"]
        response["speech_validation"] = {**quality, "state": quality.get("state_name", quality["state"])}
        response["speech_quality"] = quality
        response["status"] = "completed"
        return response

    except Exception as e:
        logger.exception("Analysis failure")
        return JSONResponse(status_code=500, content={
            "success": False,
            "error": "Internal analysis error. Please check the server logs.",
        })


if __name__ == "__main__":
    import uvicorn
    _warmup()
    uvicorn.run(app, host="127.0.0.1", port=8000, reload=False)
