"""End-to-end reliability battery for the Scam Detector API.

Ground-truth assertions are only made where behavior is deterministic and
logically required (silence -> no voice, corrupt -> 400, oversize -> 413...).
Synthetic "speech" fixtures assert structural outcomes (SPEECH state, valid
schema), never a specific HUMAN/AI verdict.
"""
from __future__ import annotations

import io
import time
import wave
from pathlib import Path

import sys

import httpx
import pytest
from fastapi import UploadFile

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

FIX: Path = None  # set in fixture


@pytest.fixture(scope="module")
def fx(fixtures) -> Path:
    global FIX
    FIX = fixtures
    return fixtures


def post_audio(client: httpx.Client, path: Path, mime: str = "audio/wav"):
    return client.post(
        "/check_voice",
        files={"audio": (path.name, path.read_bytes(), mime)},
    )


def post_bytes(client: httpx.Client, name: str, content: bytes, mime: str = "audio/wav"):
    return client.post(
        "/check_voice",
        files={"audio": (name, content, mime)},
    )


# ------------------------------------------------------------------
# Health & pages
# ------------------------------------------------------------------

def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    d = r.json()
    assert d["status"] == "online"
    assert d["features"] == 22


def test_pages_render(client):
    for path in ("/", "/upload"):
        r = client.get(path)
        assert r.status_code == 200
        assert "Voice Call AI Detector" in r.text


def test_favicon(client):
    r = client.get("/favicon.ico")
    assert r.status_code == 200


# ------------------------------------------------------------------
# Deterministic speech-validation outcomes
# ------------------------------------------------------------------

def test_silence_is_no_voice(client, fx):
    r = post_audio(client, fx / "silence.wav")
    assert r.status_code == 200
    d = r.json()
    assert d["success"] is True
    assert d["voice_detected"] is False
    assert d["speech_state"] == "NO_SPEECH"
    assert d["label"] == "NO VOICE DETECTED"
    assert d["risk_level"] == "NONE"
    # must NOT present a normal voice verdict
    assert "HUMAN" != d["label"] and "AI" not in d["label"]


def test_white_noise_is_not_classified(client, fx):
    r = post_audio(client, fx / "noise.wav")
    assert r.status_code == 200
    d = r.json()
    assert d["voice_detected"] is False, f"white noise leaked to model: {d}"
    assert d["speech_state"] == "NO_SPEECH"


def test_pink_noise_is_not_classified(client, fx):
    r = post_audio(client, fx / "pink_noise.wav")
    d = r.json()
    assert d["voice_detected"] is False, f"pink noise leaked to model: {d}"


def test_constant_tone_is_not_classified(client, fx):
    r = post_audio(client, fx / "tone.wav")
    d = r.json()
    assert d["voice_detected"] is False, f"tone leaked to model: {d}"
    assert d["speech_state"] == "NO_SPEECH"


def test_classifier_bypass_for_non_speech_and_valid_speech(monkeypatch, fx):
    import asyncio
    import app as app_module

    calls = {"count": 0}

    def fake_predict(y):
        calls["count"] += 1
        return {
            "label": "HUMAN",
            "signal": "GREEN",
            "risk_level": "LOW",
            "uncertain": False,
            "detection_score": 80.0,
            "score_basis": "uncalibrated_randomforest_vote_share",
            "risk_score": 20.0,
            "human_confidence": 80.0,
            "ai_probability": 20.0,
            "aasist": {"spoof_logit": 0.0, "bona_fide_logit": 0.0, "logit_difference": 0.0},
            "message": "test",
        }

    monkeypatch.setattr(app_module, "predict", fake_predict)
    for name in ("silence.wav", "noise.wav", "pink_noise.wav", "tone.wav", "music_like.wav", "short_speech.wav"):
        file = UploadFile(filename=name, file=io.BytesIO((fx / name).read_bytes()))
        response = asyncio.run(app_module.check_voice(audio=file))
        assert response["success"] is True
        assert response["voice_detected"] is False
        assert response["speech_state"] in {"NO_SPEECH", "INSUFFICIENT_SPEECH", "UNCERTAIN"}
    assert calls["count"] == 0

    speech_file = UploadFile(filename="speech_human.wav", file=io.BytesIO((fx / "speech_human.wav").read_bytes()))
    response = asyncio.run(app_module.check_voice(audio=speech_file))
    assert response["success"] is True
    assert response["voice_detected"] is True
    assert response["speech_state"] == "SPEECH"
    assert calls["count"] == 1


def test_speech_passes_gate(client, fx):
    r = post_audio(client, fx / "speech_human.wav")
    d = r.json()
    assert r.status_code == 200 and d["success"] is True
    assert d["voice_detected"] is True
    assert d["speech_state"] == "SPEECH"
    assert d["label"] in ("HUMAN", "AI / SPOOF")
    assert 0.0 <= d["detection_score"] <= 100.0


def test_speech_with_noise_passes_gate(client, fx):
    r = post_audio(client, fx / "speech_with_noise.wav")
    d = r.json()
    assert d["voice_detected"] is True, f"noisy speech rejected: {d}"
    assert d["speech_state"] in ("SPEECH", "UNCERTAIN")


def test_short_speech_never_hard_rejected_into_model_without_flag(client, fx):
    r = post_audio(client, fx / "short_speech.wav")
    d = r.json()
    assert r.status_code == 200
    # Either gated out (INSUFFICIENT_SPEECH) or flagged UNCERTAIN - never a plain confident verdict
    if d["voice_detected"]:
        assert d["speech_state"] == "UNCERTAIN"
        assert d["risk_level"] == "UNCERTAIN"
    else:
        assert d["speech_state"] == "INSUFFICIENT_SPEECH"


# ------------------------------------------------------------------
# Error handling (deterministic)
# ------------------------------------------------------------------

def test_empty_upload(client):
    r = post_bytes(client, "empty.wav", b"")
    assert r.status_code == 400
    assert r.json()["success"] is False


def test_corrupt_file_400(client, fx):
    r = post_audio(client, fx / "corrupt.wav")
    assert r.status_code == 400
    d = r.json()
    assert d["success"] is False
    assert "FFmpeg is not installed" not in d["error"]  # no misleading legacy error


def test_oversize_413(client, fx):
    r = post_audio(client, fx / "oversize.bin")
    assert r.status_code == 413
    assert "too large" in r.json()["error"]


def test_internal_errors_are_sanitized(client, fx):
    # A valid container with garbage inside exercises decode failure paths;
    # whatever the outcome, no stack trace or internal path may leak.
    garbage = fx / "corrupt.wav"
    r = post_audio(client, garbage)
    body = r.text
    assert "Traceback" not in body
    assert "C:\\" not in body and "/home/" not in body


# ------------------------------------------------------------------
# Formats actually supported by this environment
# ------------------------------------------------------------------

def test_wav(client, fx):
    r = post_audio(client, fx / "speech_human.wav")
    assert r.status_code == 200 and r.json()["success"]


def test_resampling_24k(client, fx):
    r = post_audio(client, fx / "short_24k.wav")
    d = r.json()
    assert r.status_code == 200 and d["success"]
    assert d["metadata"]["sample_rate"] == 16000
    assert d["metadata"]["resampled"] is True


def test_mp3(client, fx):
    p = fx / "speech.mp3"
    if not p.exists():
        pytest.skip("MP3 fixture unavailable")
    r = post_audio(client, p, "audio/mpeg")
    assert r.status_code == 200 and r.json()["success"]


def test_webm(client, fx):
    p = fx / "speech.webm"
    if not p.exists():
        pytest.skip("WebM fixture unavailable")
    r = post_audio(client, p, "audio/webm")
    assert r.status_code == 200 and r.json()["success"]


def test_m4a(client, fx):
    p = fx / "speech.m4a"
    if not p.exists():
        pytest.skip("M4A fixture unavailable")
    r = post_audio(client, p, "audio/mp4")
    assert r.status_code == 200 and r.json()["success"]


def test_long_60s(client, fx):
    r = post_audio(client, fx / "long_60s.wav")
    d = r.json()
    assert r.status_code == 200 and d["success"]
    assert d["metadata"]["duration_seconds"] == 60.0


def test_over_180s_rejected(client):
    # 200 s of silence decodes fast and must hit the duration cap
    sr = 8000  # low rate keeps payload small but duration long after decode
    n = sr * 200
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(b"\x00\x00" * n)
    r = post_bytes(client, "toolong.wav", buf.getvalue())
    assert r.status_code == 400
    assert "maximum supported duration" in r.json()["error"]


# ------------------------------------------------------------------
# Score semantics
# ------------------------------------------------------------------

def test_score_semantics_and_risk_levels(client, fx):
    r = post_audio(client, fx / "speech_human.wav")
    d = r.json()
    assert d["score_basis"] == "uncalibrated_randomforest_vote_share"
    assert d["risk_level"] in ("LOW", "MEDIUM", "HIGH", "UNCERTAIN")
    # back-compat fields still present
    for k in ("risk_score", "human_confidence", "ai_probability", "label", "signal"):
        assert k in d
    # detection_score is the winning share; consistency check
    assert d["detection_score"] == pytest.approx(
        max(d["human_confidence"], d["ai_probability"]), abs=0.01
    )


def test_disclaimer_present(client, fx):
    r = post_audio(client, fx / "speech_human.wav")
    assert "not definitive proof" in r.json()["disclaimer"]


def test_uncertain_path_exists_by_contract(client, fx):
    """The API must be able to express UNCERTAIN (risk_level vocabulary)."""
    r = post_audio(client, fx / "short_speech.wav")
    d = r.json()
    assert d["risk_level"] in ("LOW", "MEDIUM", "HIGH", "UNCERTAIN", "NONE")


# ------------------------------------------------------------------
# Concurrency (no crashes, no mixed state, correct isolated results)
# ------------------------------------------------------------------

def test_concurrent_5(client, fx):
    import concurrent.futures
    payload = (fx / "speech_human.wav").read_bytes()

    def one(i):
        r = post_bytes(client, f"c{i}.wav", payload)
        return r.status_code, r.json()

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        results = list(ex.map(one, range(5)))

    codes = [c for c, _ in results]
    assert all(c == 200 for c in codes), results
    # deterministic model: identical payloads must produce identical scores
    scores = {j["detection_score"] for _, j in results}
    assert len(scores) == 1, f"non-deterministic under concurrency: {scores}"
    labels = {j["label"] for _, j in results}
    assert len(labels) == 1


# ------------------------------------------------------------------
# Temp-file cleanup across failure modes
# ------------------------------------------------------------------

def test_no_temp_files_left_behind(client, fx, tmp_path):
    import os
    import tempfile as tf

    before = set(os.listdir(tf.gettempdir()))

    # success path
    post_audio(client, fx / "speech_human.wav")
    # silence path (no ffmpeg)
    post_audio(client, fx / "silence.wav")
    # corrupt path (ffmpeg runs and fails)
    post_audio(client, fx / "corrupt.wav")
    # oversize (rejected before decode)
    post_bytes(client, "big.bin", b"\0" * (26 * 1024 * 1024))

    after = set(os.listdir(tf.gettempdir()))
    new_entries = {n for n in after - before if not n.startswith("pip-")}
    # Allow unrelated concurrent temp churn; assert none look like our audio temps
    suspicious = [n for n in new_entries if n.endswith((".input", ".wav"))]
    assert not suspicious, f"leftover temp files: {suspicious}"


def test_filename_never_touches_filesystem(client, fx):
    # path-traversal-style filename must be harmless
    payload = (fx / "speech_human.wav").read_bytes()
    r = client.post(
        "/check_voice",
        files={"audio": ("../../etc/passwd.wav", payload, "audio/wav")},
    )
    assert r.status_code == 200
    assert r.json()["success"] is True
    # nothing was written next to the app
    assert not (fx.parent / "etc").exists()
