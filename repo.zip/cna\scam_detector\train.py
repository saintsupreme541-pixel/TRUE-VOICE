# ============================================================
# VOICE_CALL - FRESH VOICE CLONING DETECTION TRAINING
# ============================================================
#
# This project is completely independent.
#
# Model:
#   trained_model/voice_call_model.joblib
#
# Report:
#   trained_model/training_report.json
#
# Classes:
#   0 = HUMAN
#   1 = AI/SPOOF
#
# Features:
#   3  AASIST-derived features
#   13 Acoustic features
#   6  Prosody features
#   ---------------------
#   22 total features
#
# ============================================================

import os
import json
import random
import warnings
from pathlib import Path

import joblib
import numpy as np
import librosa
import onnxruntime as ort

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
)

warnings.filterwarnings("ignore")


# ============================================================
# PROJECT PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

DATASET_DIR = BASE_DIR / "dataset"

HUMAN_DIR = DATASET_DIR / "human"
AI_DIR = DATASET_DIR / "ai"

MIC_DIR = DATASET_DIR / "microphone"
MIC_HUMAN_DIR = MIC_DIR / "human"
MIC_AI_DIR = MIC_DIR / "ai"

AASIST_PATH = BASE_DIR / "aasist.onnx"

TRAINED_DIR = BASE_DIR / "trained_model"

MODEL_PATH = TRAINED_DIR / "voice_call_model.joblib"
REPORT_PATH = TRAINED_DIR / "training_report.json"


# ============================================================
# CONSTANTS
# ============================================================

SR = 16000

AASIST_SAMPLES = 64600

RANDOM_SEED = 42

random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)


# ============================================================
# SETTINGS
# ============================================================

AUDIO_EXTENSIONS = {
    ".wav",
    ".mp3",
    ".flac",
    ".ogg",
    ".m4a",
    ".aac",
}


# ============================================================
# PRINT HEADER
# ============================================================

print()
print("=" * 70)
print("VOICE_CALL - FRESH MODEL TRAINING")
print("=" * 70)
print("Project folder:")
print(BASE_DIR)
print()
print("Model will be saved to:")
print(MODEL_PATH)
print()
print("No old model will be used.")
print("=" * 70)


# ============================================================
# CHECK DIRECTORIES
# ============================================================

TRAINED_DIR.mkdir(parents=True, exist_ok=True)

for directory in [
    HUMAN_DIR,
    AI_DIR,
    MIC_HUMAN_DIR,
    MIC_AI_DIR,
]:
    directory.mkdir(parents=True, exist_ok=True)


# ============================================================
# CHECK AASIST
# ============================================================

if not AASIST_PATH.exists():
    raise FileNotFoundError(
        f"\nAASIST model not found:\n{AASIST_PATH}\n\n"
        "Copy aasist.onnx into the voice_call folder."
    )


# ============================================================
# LOAD AASIST
# ============================================================

print()
print("=" * 70)
print("LOADING AASIST")
print("=" * 70)

aasist_session = ort.InferenceSession(
    str(AASIST_PATH),
    providers=["CPUExecutionProvider"],
)

aasist_input = aasist_session.get_inputs()[0]

print("AASIST input:", aasist_input.name)
print("AASIST shape:", aasist_input.shape)

AASIST_INPUT_NAME = aasist_input.name


# ============================================================
# FILE COLLECTION
# ============================================================

def collect_audio_files(directory):
    """
    Recursively collect supported audio files.
    """

    directory = Path(directory)

    if not directory.exists():
        return []

    files = []

    for path in directory.rglob("*"):
        if path.is_file() and path.suffix.lower() in AUDIO_EXTENSIONS:
            files.append(path)

    return sorted(files)


# ============================================================
# DATASET FILES
# ============================================================

human_files = collect_audio_files(HUMAN_DIR)
ai_files = collect_audio_files(AI_DIR)

mic_human_files = collect_audio_files(MIC_HUMAN_DIR)
mic_ai_files = collect_audio_files(MIC_AI_DIR)


print()
print("Clean HUMAN:", len(human_files))
print("Clean AI:", len(ai_files))
print("Mic HUMAN:", len(mic_human_files))
print("Mic AI:", len(mic_ai_files))


if len(human_files) == 0:
    raise RuntimeError(
        f"No HUMAN audio files found in:\n{HUMAN_DIR}"
    )

if len(ai_files) == 0:
    raise RuntimeError(
        f"No AI audio files found in:\n{AI_DIR}"
    )


# ============================================================
# AUDIO LOADING
# ============================================================

def load_audio(path):
    """
    Load audio as mono 16 kHz float32.
    """

    try:

        y, sr = librosa.load(
            str(path),
            sr=SR,
            mono=True,
        )

        if y is None or len(y) == 0:
            return None

        y = np.asarray(y, dtype=np.float32)

        # Remove invalid values
        y = np.nan_to_num(
            y,
            nan=0.0,
            posinf=0.0,
            neginf=0.0,
        )

        # Normalize only if necessary
        peak = np.max(np.abs(y))

        if peak > 1.0:
            y = y / peak

        return y

    except Exception as e:

        print(
            f"WARNING: Could not load {path.name}: {e}"
        )

        return None


# ============================================================
# FIX AUDIO LENGTH FOR AASIST
# ============================================================

def prepare_aasist_audio(y):
    """
    AASIST expects 64600 samples.
    """

    if y is None or len(y) == 0:
        return None

    y = np.asarray(y, dtype=np.float32)

    if len(y) < AASIST_SAMPLES:

        padded = np.zeros(
            AASIST_SAMPLES,
            dtype=np.float32,
        )

        padded[:len(y)] = y

        return padded

    if len(y) > AASIST_SAMPLES:

        return y[:AASIST_SAMPLES]

    return y


# ============================================================
# AASIST FEATURES
# ============================================================

def extract_aasist_features(y):
    """
    Extract 3 AASIST-derived values.

    These are raw model logits / score differences.
    They are NOT probabilities.
    """

    try:

        wav = prepare_aasist_audio(y)

        if wav is None:
            return None

        input_data = wav.reshape(
            1,
            AASIST_SAMPLES
        ).astype(np.float32)

        outputs = aasist_session.run(
            None,
            {
                AASIST_INPUT_NAME: input_data
            },
        )

        logits = np.asarray(
            outputs[0]
        ).reshape(-1)

        if len(logits) < 2:
            return None

        logit0 = float(logits[0])
        logit1 = float(logits[1])

        difference = logit0 - logit1

        return np.array(
            [
                logit0,
                logit1,
                difference,
            ],
            dtype=np.float32,
        )

    except Exception as e:

        print(
            f"WARNING: AASIST feature extraction failed: {e}"
        )

        return None


# ============================================================
# ACOUSTIC FEATURES - 13
# ============================================================

def extract_acoustic_features(y):
    """
    13 acoustic features:

    1  spectral centroid mean
    2  spectral centroid std

    3  spectral bandwidth mean
    4  spectral bandwidth std

    5  spectral rolloff mean
    6  spectral rolloff std

    7  spectral flatness mean
    8  spectral flatness std

    9  zero crossing rate mean
    10 zero crossing rate std

    11 RMS mean
    12 RMS std

    13 MFCC variability
    """

    try:

        if y is None or len(y) < 512:
            return None

        centroid = librosa.feature.spectral_centroid(
            y=y,
            sr=SR,
        )

        bandwidth = librosa.feature.spectral_bandwidth(
            y=y,
            sr=SR,
        )

        rolloff = librosa.feature.spectral_rolloff(
            y=y,
            sr=SR,
            roll_percent=0.85,
        )

        flatness = librosa.feature.spectral_flatness(
            y=y,
        )

        zcr = librosa.feature.zero_crossing_rate(
            y,
        )

        rms = librosa.feature.rms(
            y=y,
        )

        mfcc = librosa.feature.mfcc(
            y=y,
            sr=SR,
            n_mfcc=13,
        )

        features = [

            float(np.mean(centroid)),
            float(np.std(centroid)),

            float(np.mean(bandwidth)),
            float(np.std(bandwidth)),

            float(np.mean(rolloff)),
            float(np.std(rolloff)),

            float(np.mean(flatness)),
            float(np.std(flatness)),

            float(np.mean(zcr)),
            float(np.std(zcr)),

            float(np.mean(rms)),
            float(np.std(rms)),

            float(np.mean(np.std(mfcc, axis=1))),
        ]

        features = np.asarray(
            features,
            dtype=np.float32,
        )

        features = np.nan_to_num(
            features,
            nan=0.0,
            posinf=0.0,
            neginf=0.0,
        )

        return features

    except Exception as e:

        print(
            f"WARNING: Acoustic feature extraction failed: {e}"
        )

        return None


# ============================================================
# PROSODY FEATURES - 6
# ============================================================

def extract_prosody_features(y):
    """
    6 prosody features:

    1 pitch mean
    2 pitch std
    3 pitch range
    4 voiced ratio
    5 jitter-like measure
    6 energy variation
    """

    try:

        if y is None or len(y) < 1024:
            return None

        # ----------------------------------------------------
        # PITCH
        # ----------------------------------------------------

        f0, voiced_flag, voiced_probs = librosa.pyin(
            y,
            fmin=librosa.note_to_hz("C2"),
            fmax=librosa.note_to_hz("C7"),
            sr=SR,
        )

        valid_f0 = f0[np.isfinite(f0)]

        if len(valid_f0) > 0:

            pitch_mean = float(
                np.mean(valid_f0)
            )

            pitch_std = float(
                np.std(valid_f0)
            )

            pitch_range = float(
                np.max(valid_f0)
                -
                np.min(valid_f0)
            )

        else:

            pitch_mean = 0.0
            pitch_std = 0.0
            pitch_range = 0.0

        # ----------------------------------------------------
        # VOICED RATIO
        # ----------------------------------------------------

        if voiced_flag is not None:

            voiced_ratio = float(
                np.mean(
                    voiced_flag.astype(np.float32)
                )
            )

        else:

            voiced_ratio = 0.0

        # ----------------------------------------------------
        # JITTER-LIKE MEASURE
        # ----------------------------------------------------

        if len(valid_f0) > 2:

            differences = np.diff(valid_f0)

            mean_period_change = np.mean(
                np.abs(differences)
            )

            mean_f0 = np.mean(valid_f0)

            if mean_f0 > 0:

                jitter_like = float(
                    mean_period_change
                    /
                    mean_f0
                )

            else:

                jitter_like = 0.0

        else:

            jitter_like = 0.0

        # ----------------------------------------------------
        # ENERGY VARIATION
        # ----------------------------------------------------

        rms = librosa.feature.rms(
            y=y
        )[0]

        if len(rms) > 1:

            energy_mean = np.mean(rms)

            if energy_mean > 0:

                energy_variation = float(
                    np.std(rms)
                    /
                    energy_mean
                )

            else:

                energy_variation = 0.0

        else:

            energy_variation = 0.0

        features = np.array(
            [
                pitch_mean,
                pitch_std,
                pitch_range,
                voiced_ratio,
                jitter_like,
                energy_variation,
            ],
            dtype=np.float32,
        )

        features = np.nan_to_num(
            features,
            nan=0.0,
            posinf=0.0,
            neginf=0.0,
        )

        return features

    except Exception as e:

        print(
            f"WARNING: Prosody feature extraction failed: {e}"
        )

        return None


# ============================================================
# COMPLETE FEATURE EXTRACTION
# ============================================================

def extract_features(path):
    """
    Extract all 22 features.
    """

    y = load_audio(path)

    if y is None:
        return None

    aasist = extract_aasist_features(y)

    acoustic = extract_acoustic_features(y)

    prosody = extract_prosody_features(y)

    if aasist is None:
        return None

    if acoustic is None:
        return None

    if prosody is None:
        return None

    features = np.concatenate(
        [
            aasist,
            acoustic,
            prosody,
        ]
    )

    if len(features) != 22:

        print(
            f"WARNING: Wrong feature count for {path.name}: "
            f"{len(features)}"
        )

        return None

    features = np.nan_to_num(
        features,
        nan=0.0,
        posinf=0.0,
        neginf=0.0,
    )

    return features.astype(np.float32)


# ============================================================
# BUILD DATASET
# ============================================================

def build_dataset(
    human_paths,
    ai_paths,
):
    """
    Build feature matrix and labels.

    HUMAN = 0
    AI    = 1
    """

    X = []
    y = []

    # --------------------------------------------------------
    # HUMAN
    # --------------------------------------------------------

    for index, path in enumerate(human_paths):

        print(
            f"\rProcessing HUMAN "
            f"{index + 1}/{len(human_paths)}",
            end="",
        )

        features = extract_features(path)

        if features is not None:

            X.append(features)
            y.append(0)

    print()

    # --------------------------------------------------------
    # AI
    # --------------------------------------------------------

    for index, path in enumerate(ai_paths):

        print(
            f"\rProcessing AI "
            f"{index + 1}/{len(ai_paths)}",
            end="",
        )

        features = extract_features(path)

        if features is not None:

            X.append(features)
            y.append(1)

    print()

    if len(X) == 0:

        return (
            np.empty((0, 22), dtype=np.float32),
            np.empty((0,), dtype=np.int64),
        )

    return (
        np.asarray(X, dtype=np.float32),
        np.asarray(y, dtype=np.int64),
    )


# ============================================================
# TRAIN / VALIDATION / TEST SPLIT
# ============================================================

def split_paths(paths):
    """
    70% train
    15% validation
    15% test
    """

    paths = list(paths)

    random.shuffle(paths)

    n = len(paths)

    train_end = int(
        n * 0.70
    )

    val_end = int(
        n * 0.85
    )

    train = paths[:train_end]

    validation = paths[
        train_end:val_end
    ]

    test = paths[
        val_end:
    ]

    return train, validation, test


# ============================================================
# MICROPHONE SPLIT
# ============================================================

def split_microphone_paths(paths):
    """
    70% microphone training
    30% microphone holdout
    """

    paths = list(paths)

    random.shuffle(paths)

    if len(paths) < 2:

        return paths, []

    train_end = int(
        len(paths) * 0.70
    )

    # Always keep at least one holdout sample
    if train_end >= len(paths):

        train_end = len(paths) - 1

    train = paths[:train_end]

    holdout = paths[train_end:]

    return train, holdout


# ============================================================
# SYNTHETIC MICROPHONE AUGMENTATION
# ============================================================

def microphone_augmentation(y):
    """
    Create a microphone-like version of audio.

    The original file is not modified.
    """

    if y is None or len(y) == 0:
        return y

    augmented = np.asarray(
        y,
        dtype=np.float32
    ).copy()

    try:

        # ----------------------------------------------------
        # Random gain
        # ----------------------------------------------------

        gain = np.random.uniform(
            0.75,
            1.05,
        )

        augmented *= gain

        # ----------------------------------------------------
        # Add low-level noise
        # ----------------------------------------------------

        noise_level = np.random.uniform(
            0.001,
            0.008,
        )

        noise = np.random.normal(
            0,
            noise_level,
            len(augmented),
        ).astype(np.float32)

        augmented += noise

        # ----------------------------------------------------
        # Simple room / microphone filtering
        # ----------------------------------------------------

        if len(augmented) > 1000:

            augmented = librosa.effects.preemphasis(
                augmented,
                coef=0.97,
            )

        # ----------------------------------------------------
        # Prevent clipping
        # ----------------------------------------------------

        peak = np.max(
            np.abs(augmented)
        )

        if peak > 1.0:

            augmented /= peak

        return augmented.astype(
            np.float32
        )

    except Exception:

        return y


# ============================================================
# BUILD SYNTHETIC DATASET
# ============================================================

def build_synthetic_dataset(
    human_paths,
    ai_paths,
):
    """
    One synthetic microphone version per clean
    training audio.
    """

    X = []
    y = []

    all_items = []

    for path in human_paths:
        all_items.append(
            (path, 0)
        )

    for path in ai_paths:
        all_items.append(
            (path, 1)
        )

    for index, (path, label) in enumerate(
        all_items
    ):

        print(
            f"\rSynthetic microphone "
            f"{index + 1}/{len(all_items)}",
            end="",
        )

        original = load_audio(path)

        if original is None:
            continue

        augmented = microphone_augmentation(
            original
        )

        aasist = extract_aasist_features(
            augmented
        )

        acoustic = extract_acoustic_features(
            augmented
        )

        prosody = extract_prosody_features(
            augmented
        )

        if (
            aasist is None
            or acoustic is None
            or prosody is None
        ):
            continue

        features = np.concatenate(
            [
                aasist,
                acoustic,
                prosody,
            ]
        )

        if len(features) != 22:
            continue

        X.append(
            features.astype(
                np.float32
            )
        )

        y.append(label)

    print()

    if len(X) == 0:

        return (
            np.empty(
                (0, 22),
                dtype=np.float32,
            ),
            np.empty(
                (0,),
                dtype=np.int64,
            ),
        )

    return (
        np.asarray(
            X,
            dtype=np.float32,
        ),
        np.asarray(
            y,
            dtype=np.int64,
        ),
    )


# ============================================================
# BUILD MICROPHONE DATASET
# ============================================================

def build_mic_dataset(
    human_paths,
    ai_paths,
):
    """
    Build microphone feature dataset.

    HUMAN = 0
    AI = 1
    """

    X = []
    y = []

    all_items = []

    for path in human_paths:

        all_items.append(
            (path, 0)
        )

    for path in ai_paths:

        all_items.append(
            (path, 1)
        )

    for index, (path, label) in enumerate(
        all_items
    ):

        print(
            f"\rProcessing MICROPHONE "
            f"{index + 1}/{len(all_items)}",
            end="",
        )

        features = extract_features(
            path
        )

        if features is not None:

            X.append(features)
            y.append(label)

    print()

    if len(X) == 0:

        return (
            np.empty(
                (0, 22),
                dtype=np.float32,
            ),
            np.empty(
                (0,),
                dtype=np.int64,
            ),
        )

    return (
        np.asarray(
            X,
            dtype=np.float32,
        ),
        np.asarray(
            y,
            dtype=np.int64,
        ),
    )


# ============================================================
# SPLIT CLEAN DATA
# ============================================================

human_train, human_val, human_test = split_paths(
    human_files
)

ai_train, ai_val, ai_test = split_paths(
    ai_files
)


# ============================================================
# SPLIT REAL MICROPHONE DATA
# ============================================================

mic_human_train, mic_human_holdout = (
    split_microphone_paths(
        mic_human_files
    )
)

mic_ai_train, mic_ai_holdout = (
    split_microphone_paths(
        mic_ai_files
    )
)


# ============================================================
# BUILD CLEAN TRAINING DATA
# ============================================================

print()
print("=" * 70)
print("BUILDING CLEAN TRAINING DATA")
print("=" * 70)

X_clean_train, y_clean_train = build_dataset(
    human_train,
    ai_train,
)

print(
    "Clean training samples:",
    len(X_clean_train)
)


# ============================================================
# BUILD SYNTHETIC MICROPHONE DATA
# ============================================================

print()
print("=" * 70)
print("BUILDING SYNTHETIC MICROPHONE AUGMENTATIONS")
print("=" * 70)

X_synthetic, y_synthetic = build_synthetic_dataset(
    human_train,
    ai_train,
)

print(
    "Synthetic microphone samples:",
    len(X_synthetic)
)


# ============================================================
# BUILD REAL MICROPHONE TRAINING DATA
# ============================================================

print()
print("=" * 70)
print("BUILDING REAL MICROPHONE TRAINING DATA")
print("=" * 70)

X_mic_train, y_mic_train = build_mic_dataset(
    mic_human_train,
    mic_ai_train,
)

print(
    "Real microphone training samples:",
    len(X_mic_train)
)


# ============================================================
# COMBINE TRAINING DATA
# ============================================================

training_arrays = []

label_arrays = []

if len(X_clean_train) > 0:

    training_arrays.append(
        X_clean_train
    )

    label_arrays.append(
        y_clean_train
    )


if len(X_synthetic) > 0:

    training_arrays.append(
        X_synthetic
    )

    label_arrays.append(
        y_synthetic
    )


if len(X_mic_train) > 0:

    training_arrays.append(
        X_mic_train
    )

    label_arrays.append(
        y_mic_train
    )


if len(training_arrays) == 0:

    raise RuntimeError(
        "No valid training samples were created."
    )


X_train = np.vstack(
    training_arrays
)

y_train = np.concatenate(
    label_arrays
)


print()
print("=" * 70)
print("TRAINING DATA SUMMARY")
print("=" * 70)

print(
    "Clean training samples:",
    len(X_clean_train)
)

print(
    "Synthetic microphone samples:",
    len(X_synthetic)
)

print(
    "Real microphone training samples:",
    len(X_mic_train)
)

print(
    "TOTAL TRAINING SAMPLES:",
    len(X_train)
)

print(
    "FEATURE COUNT:",
    X_train.shape[1]
)


# ============================================================
# BUILD VALIDATION DATA
# ============================================================

print()
print("=" * 70)
print("BUILDING VALIDATION DATA")
print("=" * 70)

X_val, y_val = build_dataset(
    human_val,
    ai_val,
)

print(
    "Validation samples:",
    len(X_val)
)


# ============================================================
# BUILD CLEAN TEST DATA
# ============================================================

print()
print("=" * 70)
print("BUILDING CLEAN TEST DATA")
print("=" * 70)

X_clean_test, y_clean_test = build_dataset(
    human_test,
    ai_test,
)

print(
    "Clean test samples:",
    len(X_clean_test)
)


# ============================================================
# SCALER
# ============================================================

print()
print("=" * 70)
print("FITTING FEATURE SCALER")
print("=" * 70)

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(
    X_train
)


# ============================================================
# CLASSIFIER
# ============================================================

print()
print("=" * 70)
print("TRAINING NEW VOICE_CALL MODEL")
print("=" * 70)

classifier = RandomForestClassifier(
    n_estimators=500,
    max_depth=12,
    min_samples_leaf=2,
    class_weight="balanced",
    random_state=RANDOM_SEED,
    n_jobs=-1,
)


classifier.fit(
    X_train_scaled,
    y_train,
)


# ============================================================
# VALIDATION
# ============================================================

print()
print("=" * 70)
print("VALIDATION RESULTS")
print("=" * 70)

if len(X_val) > 0:

    X_val_scaled = scaler.transform(
        X_val
    )

    val_predictions = classifier.predict(
        X_val_scaled
    )

    val_accuracy = accuracy_score(
        y_val,
        val_predictions,
    )

    val_precision = precision_score(
        y_val,
        val_predictions,
        zero_division=0,
    )

    val_recall = recall_score(
        y_val,
        val_predictions,
        zero_division=0,
    )

    val_f1 = f1_score(
        y_val,
        val_predictions,
        zero_division=0,
    )

    val_cm = confusion_matrix(
        y_val,
        val_predictions,
    )

    print(
        classification_report(
            y_val,
            val_predictions,
            target_names=[
                "HUMAN",
                "AI",
            ],
            zero_division=0,
        )
    )

else:

    print(
        "No validation samples available."
    )

    val_accuracy = 0.0
    val_precision = 0.0
    val_recall = 0.0
    val_f1 = 0.0
    val_cm = np.zeros(
        (2, 2),
        dtype=int,
    )


# ============================================================
# CLEAN TEST
# ============================================================

print()
print("=" * 70)
print("CLEAN TEST")
print("=" * 70)

if len(X_clean_test) > 0:

    X_clean_test_scaled = scaler.transform(
        X_clean_test
    )

    clean_predictions = classifier.predict(
        X_clean_test_scaled
    )

    clean_accuracy = accuracy_score(
        y_clean_test,
        clean_predictions,
    )

    clean_precision = precision_score(
        y_clean_test,
        clean_predictions,
        zero_division=0,
    )

    clean_recall = recall_score(
        y_clean_test,
        clean_predictions,
        zero_division=0,
    )

    clean_f1 = f1_score(
        y_clean_test,
        clean_predictions,
        zero_division=0,
    )

    clean_cm = confusion_matrix(
        y_clean_test,
        clean_predictions,
    )

    print(
        "Accuracy:",
        clean_accuracy,
    )

    print(
        "Precision:",
        clean_precision,
    )

    print(
        "Recall:",
        clean_recall,
    )

    print(
        "F1:",
        clean_f1,
    )

    print(
        "Confusion matrix:"
    )

    print(
        clean_cm
    )

else:

    print(
        "No clean test samples available."
    )

    clean_accuracy = 0.0
    clean_precision = 0.0
    clean_recall = 0.0
    clean_f1 = 0.0

    clean_cm = np.zeros(
        (2, 2),
        dtype=int,
    )


# ============================================================
# REAL MICROPHONE HOLDOUT
# ============================================================

print()
print("=" * 70)
print("REAL MICROPHONE HOLDOUT")
print("=" * 70)

print(
    "Microphone HUMAN holdout:",
    len(mic_human_holdout)
)

print(
    "Microphone AI holdout:",
    len(mic_ai_holdout)
)


X_mic_test, y_mic_test = build_mic_dataset(
    mic_human_holdout,
    mic_ai_holdout,
)


if (
    X_mic_test is None
    or len(X_mic_test) == 0
):

    print()
    print(
        "No valid microphone holdout samples found."
    )

    print(
        "Microphone evaluation skipped."
    )

    mic_accuracy = 0.0
    mic_precision = 0.0
    mic_recall = 0.0
    mic_f1 = 0.0

    mic_cm = np.zeros(
        (2, 2),
        dtype=int,
    )

else:

    X_mic_test_scaled = scaler.transform(
        X_mic_test
    )

    mic_predictions = classifier.predict(
        X_mic_test_scaled
    )

    mic_accuracy = accuracy_score(
        y_mic_test,
        mic_predictions,
    )

    mic_precision = precision_score(
        y_mic_test,
        mic_predictions,
        zero_division=0,
    )

    mic_recall = recall_score(
        y_mic_test,
        mic_predictions,
        zero_division=0,
    )

    mic_f1 = f1_score(
        y_mic_test,
        mic_predictions,
        zero_division=0,
    )

    mic_cm = confusion_matrix(
        y_mic_test,
        mic_predictions,
    )

    print()
    print(
        "Accuracy:",
        mic_accuracy,
    )

    print(
        "Precision:",
        mic_precision,
    )

    print(
        "Recall:",
        mic_recall,
    )

    print(
        "F1:",
        mic_f1,
    )

    print(
        "Confusion matrix:"
    )

    print(
        mic_cm
    )


# ============================================================
# SAVE MODEL
# ============================================================

print()
print("=" * 70)
print("SAVING NEW MODEL")
print("=" * 70)


model_package = {

    "model": classifier,

    "scaler": scaler,

    "feature_count": 22,

    "sample_rate": SR,

    "aasist_samples": AASIST_SAMPLES,

    "class_mapping": {
        "0": "HUMAN",
        "1": "AI/SPOOF",
    },

    "project": "voice_call",

    "model_name": "voice_call_model",

    "random_seed": RANDOM_SEED,

    "feature_definition": {
        "aasist": 3,
        "acoustic": 13,
        "prosody": 6,
        "total": 22,
    },
}


joblib.dump(
    model_package,
    MODEL_PATH,
)


# ============================================================
# VERIFY SAVED MODEL
# ============================================================

if not MODEL_PATH.exists():

    raise RuntimeError(
        "Model file was not created."
    )


model_size_mb = (
    MODEL_PATH.stat().st_size
    /
    (1024 * 1024)
)


print(
    "Model saved successfully."
)

print(
    "Model size:",
    f"{model_size_mb:.2f} MB"
)

print(
    "Model path:",
    MODEL_PATH
)


# ============================================================
# SAVE TRAINING REPORT
# ============================================================

report = {

    "project": "voice_call",

    "model": "voice_call_model.joblib",

    "model_path": str(
        MODEL_PATH
    ),

    "feature_count": 22,

    "features": {

        "aasist": 3,

        "acoustic": 13,

        "prosody": 6,

    },

    "sample_rate": SR,

    "aasist_samples": AASIST_SAMPLES,

    "dataset": {

        "clean_human": len(
            human_files
        ),

        "clean_ai": len(
            ai_files
        ),

        "microphone_human": len(
            mic_human_files
        ),

        "microphone_ai": len(
            mic_ai_files
        ),

    },

    "training_data": {

        "clean_training_samples": int(
            len(X_clean_train)
        ),

        "synthetic_microphone_samples": int(
            len(X_synthetic)
        ),

        "real_microphone_training_samples": int(
            len(X_mic_train)
        ),

        "total_training_samples": int(
            len(X_train)
        ),

    },

    "validation": {

        "samples": int(
            len(X_val)
        ),

        "accuracy": float(
            val_accuracy
        ),

        "precision": float(
            val_precision
        ),

        "recall": float(
            val_recall
        ),

        "f1": float(
            val_f1
        ),

        "confusion_matrix": (
            val_cm.tolist()
        ),

    },

    "clean_test": {

        "samples": int(
            len(X_clean_test)
        ),

        "accuracy": float(
            clean_accuracy
        ),

        "precision": float(
            clean_precision
        ),

        "recall": float(
            clean_recall
        ),

        "f1": float(
            clean_f1
        ),

        "confusion_matrix": (
            clean_cm.tolist()
        ),

    },

    "microphone_holdout": {

        "samples": int(
            len(X_mic_test)
        ),

        "accuracy": float(
            mic_accuracy
        ),

        "precision": float(
            mic_precision
        ),

        "recall": float(
            mic_recall
        ),

        "f1": float(
            mic_f1
        ),

        "confusion_matrix": (
            mic_cm.tolist()
        ),

    },

    "class_mapping": {

        "0": "HUMAN",

        "1": "AI/SPOOF",

    },

    "model_parameters": {

        "classifier": (
            "RandomForestClassifier"
        ),

        "n_estimators": 500,

        "max_depth": 12,

        "min_samples_leaf": 2,

        "class_weight": "balanced",

        "random_state": RANDOM_SEED,

    },

    "note": (
        "Evaluation metrics describe performance on "
        "the supplied datasets and are not guarantees "
        "of real-world performance."
    ),

}


with open(
    REPORT_PATH,
    "w",
    encoding="utf-8",
) as f:

    json.dump(
        report,
        f,
        indent=2,
    )


# ============================================================
# FINAL VERIFICATION
# ============================================================

print()
print("=" * 70)
print("TRAINING COMPLETE")
print("=" * 70)

print()
print("NEW MODEL:")
print(
    MODEL_PATH
)

print()
print("NEW REPORT:")
print(
    REPORT_PATH
)

print()
print(
    "Model exists:",
    MODEL_PATH.exists()
)

print(
    "Report exists:",
    REPORT_PATH.exists()
)

print()
print(
    "This project uses ONLY:"
)

print(
    "voice_call_model.joblib"
)

print()
print(
    "Class 0 = HUMAN"
)

print(
    "Class 1 = AI/SPOOF"
)

print()
print("=" * 70)
print("DONE")
print("=" * 70)