"""Backend service modules for the Scam Detector."""
