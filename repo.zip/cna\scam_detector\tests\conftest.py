"""Shared pytest fixtures: starts the real app server once per session."""
from __future__ import annotations

import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx
import pytest

ROOT = Path(__file__).resolve().parent.parent
PORT = 8765
BASE = f"http://127.0.0.1:{PORT}"


def _port_open(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


@pytest.fixture(scope="session")
def server():
    """Start `python app.py` (with warmup) and wait for /health."""
    env = dict(os.environ)
    env["SCAM_DETECTOR_PORT"] = str(PORT)
    proc = subprocess.Popen(
        [sys.executable, "-c",
         "import sys; sys.path.insert(0, '.');"
         "import app; app._warmup();"
         "import uvicorn; uvicorn.run(app.app, host='127.0.0.1', port=8765)"],
        cwd=str(ROOT), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    deadline = time.time() + 120
    while time.time() < deadline:
        if _port_open(PORT):
            try:
                r = httpx.get(f"{BASE}/health", timeout=5)
                if r.status_code == 200:
                    break
            except Exception:
                pass
        if proc.poll() is not None:
            out = proc.stdout.read().decode(errors="replace") if proc.stdout else ""
            raise RuntimeError(f"Server died during startup:\n{out[-2000:]}")
        time.sleep(0.5)
    else:
        proc.kill()
        raise RuntimeError("Server did not become healthy in 120 s")

    yield proc

    proc.terminate()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()


@pytest.fixture(scope="session")
def client(server):
    with httpx.Client(base_url=BASE, timeout=180) as c:
        yield c


@pytest.fixture(scope="session")
def fixtures():
    import subprocess as sp
    fx = ROOT / "tests" / "fixtures"
    if not (fx / "speech_human.wav").exists():
        sp.run([sys.executable, str(ROOT / "tests" / "make_fixtures.py")],
               check=True, cwd=str(ROOT), timeout=300)
    return fx
