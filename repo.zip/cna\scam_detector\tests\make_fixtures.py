"""Generate reproducible audio fixtures for the test battery.

Run directly:  python tests/make_fixtures.py   -> creates tests/fixtures/*

Synthetic signals are used for deterministic edge cases (silence, noise, tone,
corrupt, oversize). "Speech" fixtures are synthetic speech-like signals; they
are NOT verified human or AI ground truth, so tests only assert structural
behavior (e.g. SPEECH state), never a specific HUMAN/AI verdict.
"""
from __future__ import annotations

import io
import subprocess
import wave
from pathlib import Path

import numpy as np

FIXTURES = Path(__file__).resolve().parent / "fixtures"
SR = 16000
rng = np.random.default_rng(42)

# Locate the bundled FFmpeg binary (same resolution as the app uses).
def ffmpeg_exe() -> str:
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        import shutil
        found = shutil.which("ffmpeg")
        if not found:
            raise RuntimeError("No FFmpeg available to build compressed fixtures")
        return found


def _wav_bytes(y: np.ndarray, sr: int = SR) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes((np.clip(y, -1, 1) * 32767).astype("<i2").tobytes())
    return buf.getvalue()


def gen(kind: str, seconds: float = 4.0, sr: int = SR) -> np.ndarray:
    n = int(sr * seconds)
    t = np.arange(n) / sr
    y = np.zeros(n)
    if kind == "silence":
        y = np.zeros(n)
    elif kind == "noise":
        y = 0.08 * rng.standard_normal(n)
    elif kind == "pink_noise":
        w = rng.standard_normal(n)
        X = np.fft.rfft(w)
        f = np.fft.rfftfreq(n, 1 / sr)
        f[0] = f[1]
        y = np.fft.irfft(X / np.sqrt(f), n)
        y = 0.3 * y / max(np.max(np.abs(y)), 1e-9)
    elif kind == "tone":
        y = 0.3 * np.sin(2 * np.pi * 440 * t)
    elif kind == "speech":
        f0 = 140
        y = 0.4 * np.sign(np.sin(2 * np.pi * f0 * t)) * np.exp(-3 * ((t * 4) % 1))
        y += 0.2 * np.sin(2 * np.pi * f0 * 2 * t) + 0.1 * np.sin(2 * np.pi * f0 * 3 * t)
        y += 0.01 * rng.standard_normal(n)
        y *= (np.sin(2 * np.pi * 0.5 * t) > -0.3)
    elif kind == "short_speech":
        m = int(0.4 * sr)
        tt = t[:m]
        y = 0.4 * np.sign(np.sin(2 * np.pi * 140 * tt)) * np.exp(-3 * ((tt * 4) % 1))
        y = np.pad(y, (0, n - m))
    elif kind == "speech_with_noise":
        f0 = 140
        y = 0.4 * np.sign(np.sin(2 * np.pi * f0 * t)) * np.exp(-3 * ((t * 4) % 1))
        y += 0.2 * np.sin(2 * np.pi * f0 * 2 * t)
        y *= (np.sin(2 * np.pi * 0.5 * t) > -0.3)
        y += 0.05 * rng.standard_normal(n)
    elif kind == "long_speech":
        return gen("speech", 60.0, sr)
    return np.clip(y, -1, 1).astype(np.float32)


def write_wav(name: str, y: np.ndarray, sr: int = SR) -> Path:
    path = FIXTURES / name
    path.write_bytes(_wav_bytes(y, sr))
    return path


def transcode(name: str, src: Path, fmt: str) -> Path:
    """Encode a WAV fixture into a real compressed container via FFmpeg."""
    out = FIXTURES / name
    cmd = [ffmpeg_exe(), "-y", "-i", str(src), "-ar", str(SR), "-ac", "1"]
    if fmt == "mp3":
        cmd += ["-c:a", "libmp3lame", "-b:a", "96k"]
    elif fmt == "m4a":
        cmd += ["-c:a", "aac", "-b:a", "96k"]
    elif fmt == "webm":
        cmd += ["-c:a", "libopus", "-b:a", "48k"]
    cmd += [str(out)]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    if res.returncode != 0:
        raise RuntimeError(f"FFmpeg transcode failed for {name}: {res.stderr[-400:]!r}")
    return out


def main() -> None:
    FIXTURES.mkdir(parents=True, exist_ok=True)

    write_wav("speech_human.wav", gen("speech"))          # speech-like signal (not verified ground truth)
    write_wav("speech_ai.wav", gen("continuous_speech") if False else gen("speech", 4.0))
    (FIXTURES / "speech_ai.wav").write_bytes(
        _wav_bytes(gen("speech", 4.0) * -1.0)  # polarity-flipped variant; still speech-like
    )
    write_wav("silence.wav", gen("silence"))
    write_wav("noise.wav", gen("noise"))
    write_wav("pink_noise.wav", gen("pink_noise"))
    write_wav("tone.wav", gen("tone"))
    write_wav("short_speech.wav", gen("short_speech"))
    write_wav("speech_with_noise.wav", gen("speech_with_noise"))
    write_wav("music_like.wav", gen("tone", 4.0) * 0.9 + gen("tone", 4.0) * 0.1)
    write_wav("long_60s.wav", gen("long_speech"))
    write_wav("short_24k.wav", gen("speech", 4.0, 24000))  # needs resampling

    # corrupt / oversize / empty
    (FIXTURES / "corrupt.wav").write_bytes(rng.integers(0, 256, 5000, dtype=np.uint8).tobytes())
    (FIXTURES / "oversize.bin").write_bytes(b"\0" * (26 * 1024 * 1024))
    (FIXTURES / "empty.wav").write_bytes(b"")

    # compressed containers via the bundled FFmpeg binary
    speech = FIXTURES / "speech_human.wav"
    try:
        transcode("speech.mp3", speech, "mp3")
        transcode("speech.webm", speech, "webm")
        transcode("speech.m4a", speech, "m4a")
        print("compressed fixtures written (mp3/webm/m4a)")
    except Exception as e:
        print(f"WARN: compressed fixtures skipped: {e}")

    for p in sorted(FIXTURES.iterdir()):
        print(f"  {p.name:<24} {p.stat().st_size:>10,} bytes")


if __name__ == "__main__":
    main()
