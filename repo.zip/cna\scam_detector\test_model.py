from pathlib import Path

import joblib
import librosa
import numpy as np
import onnxruntime as ort


BASE = Path(__file__).resolve().parent

MODEL_PATH = (
    BASE
    / "trained_model"
    / "voice_call_model.joblib"
)

AASIST_PATH = (
    BASE / "aasist.onnx"
)


SR = 16000

AASIST_SAMPLES = 64600


model_package = joblib.load(
    MODEL_PATH
)

classifier = (
    model_package["model"]
)

scaler = (
    model_package["scaler"]
)


aasist = ort.InferenceSession(
    str(AASIST_PATH),
    providers=[
        "CPUExecutionProvider"
    ]
)

aasist_input = (
    aasist.get_inputs()[0]
)


def extract(
    path
):

    y, _ = librosa.load(
        str(path),
        sr=SR,
        mono=True
    )


    y = np.asarray(
        y,
        dtype=np.float32
    )


    if len(y) < AASIST_SAMPLES:

        y2 = np.pad(

            y,

            (
                0,

                AASIST_SAMPLES
                - len(y)
            )

        )

    else:

        y2 = y[
            :AASIST_SAMPLES
        ]


    output = aasist.run(

        None,

        {
            aasist_input.name:
                y2.reshape(
                    1,
                    AASIST_SAMPLES
                ).astype(
                    np.float32
                )
        }

    )


    logits = np.asarray(
        output[0]
    ).reshape(-1)


    stft = np.abs(

        librosa.stft(

            y,

            n_fft=1024,

            hop_length=256

        )

    )


    centroid = (
        librosa.feature
        .spectral_centroid(
            S=stft,
            sr=SR
        )[0]
    )

    bandwidth = (
        librosa.feature
        .spectral_bandwidth(
            S=stft,
            sr=SR
        )[0]
    )

    rolloff = (
        librosa.feature
        .spectral_rolloff(
            S=stft,
            sr=SR
        )[0]
    )

    flatness = (
        librosa.feature
        .spectral_flatness(
            S=stft
        )[0]
    )

    zcr = (
        librosa.feature
        .zero_crossing_rate(
            y,
            frame_length=1024,
            hop_length=256
        )[0]
    )

    rms = (
        librosa.feature
        .rms(
            y=y,
            frame_length=1024,
            hop_length=256
        )[0]
    )

    mfcc = (
        librosa.feature
        .mfcc(
            y=y,
            sr=SR,
            n_mfcc=13,
            n_fft=1024,
            hop_length=256
        )
    )


    try:

        f0, voiced, _ = (
            librosa.pyin(

                y,

                fmin=65,

                fmax=500,

                sr=SR,

                frame_length=2048,

                hop_length=256

            )
        )

        valid = f0[
            np.isfinite(f0)
        ]

    except Exception:

        valid = np.array([])

        voiced = np.zeros(1)


    if len(valid) >= 2:

        pitch_mean = np.mean(valid)

        pitch_std = np.std(valid)

        pitch_range = np.ptp(valid)

        jitter = np.mean(
            np.abs(
                np.diff(valid)
            )
            /
            (
                valid[:-1]
                + 1e-8
            )
        )

    else:

        pitch_mean = 0

        pitch_std = 0

        pitch_range = 0

        jitter = 0


    voiced_ratio = np.mean(
        voiced.astype(float)
    )


    energy_variation = (
        np.std(rms)
        /
        (
            np.mean(rms)
            + 1e-8
        )
    )


    features = np.asarray(

        [

            float(logits[0]),

            float(logits[1]),

            float(
                logits[0]
                -
                logits[1]
            ),

            float(
                np.mean(centroid)
            ),

            float(
                np.std(centroid)
            ),

            float(
                np.mean(bandwidth)
            ),

            float(
                np.std(bandwidth)
            ),

            float(
                np.mean(rolloff)
            ),

            float(
                np.std(rolloff)
            ),

            float(
                np.mean(flatness)
            ),

            float(
                np.std(flatness)
            ),

            float(
                np.mean(zcr)
            ),

            float(
                np.std(zcr)
            ),

            float(
                np.mean(rms)
            ),

            float(
                np.std(rms)
            ),

            float(
                np.mean(
                    np.std(
                        mfcc,
                        axis=1
                    )
                )
            ),

            float(pitch_mean),

            float(pitch_std),

            float(pitch_range),

            float(voiced_ratio),

            float(jitter),

            float(energy_variation),

        ],

        dtype=np.float32
    )


    return features


def test_file(
    path
):

    features = extract(
        path
    )


    X = scaler.transform(
        features.reshape(
            1,
            -1
        )
    )


    prediction = int(
        classifier.predict(
            X
        )[0]
    )


    probabilities = (
        classifier.predict_proba(
            X
        )[0]
    )


    print()

    print(
        "=" * 60
    )

    print(
        "FILE:",
        path
    )

    print(
        "PREDICTION:",
        (
            "HUMAN"
            if prediction == 0
            else
            "AI / SPOOF"
        )
    )

    print(
        "Probabilities:",
        probabilities
    )

    print(
        "=" * 60
    )


human = (
    BASE
    / "dataset"
    / "human"
    / "human_0000.wav"
)

ai = (
    BASE
    / "dataset"
    / "ai"
    / "ai_0000.wav"
)


if human.exists():

    test_file(
        human
    )

else:

    print(
        "Human test file not found:",
        human
    )


if ai.exists():

    test_file(
        ai
    )

else:

    print(
        "AI test file not found:",
        ai
    )